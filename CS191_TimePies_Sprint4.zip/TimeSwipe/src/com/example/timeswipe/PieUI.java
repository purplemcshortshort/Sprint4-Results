/**
 * REVISED BSD LICENSE
 * Copyright (c) 2015, Patricia Kelly D. Co, Kenneth T. Otsuka, Mary Jane T. Rubio
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright
      notice, this list of conditions and the following disclaimer in the
      documentation and/or other materials provided with the distribution.
    * Neither the name of the <organization> nor the
      names of its contributors may be used to endorse or promote products
      derived from this software without specific prior written permission.

 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL Patricia Kelly Co, Mary Jane T. Rubio, and 
 * Kenneth T. Otsuka BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT 
 * OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS 
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, 
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY 
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * @author Mary Jane T. Rubio
 * This is a course requirement for CS 192 Software Eng'g II under the supervision of 
 * Prof. Ma. Rowena C. Solamo of the Department of Computer Science, College of Engineering, 
 * University of the Philippines, Diliman for AY 2014-2015.
 */
/**
 * Code History
 * @version 1.0
 * @author Patricia Kelly D. Co
 * @since 2014-11-13
 * Initial code.
 * @version 1.1
 * @author Mary Jane T. Rubio
 * @since 2015-02-10
 * Removed private class SliceUI. Modified method modify to method draw.
 */
/**
 * Created on 2014-11-13
 * Developed by Purple McShortShort
 * Client Pink PlastiCS
 * The class responsible for drawing the task slices of the PieSchedule. 
 */


package com.example.timeswipe;
import java.util.ArrayList;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.BlurMaskFilter;
import android.graphics.BlurMaskFilter.Blur;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Paint.Style;
import android.graphics.RectF;
import android.view.View;
import android.os.CountDownTimer;
import android.os.SystemClock;
import android.util.AttributeSet;

/**
 * Handles drawing of the circle with slices.
 *
 */
public class PieUI extends View {
	
		private int circleColor;
		private Paint circlePaint;
		private RectF oval = new RectF();
		private ArrayList<Slice> slices = new ArrayList<Slice>();
		/**
	      * PieUI
	      *  - constructor
	      * @since 2014-11-13
	      * @param context (Context)
	      * @return void
	      */		
	public PieUI(Context context) {
		super(context);
	}
	/**
     * PieUI
     *  - constructor
     * @since 2014-11-13
     * @param context (Context)
     * @param attrs (AttributeSet)
     * @return void
     */
	public PieUI(Context context, AttributeSet attrs){
	    super(context, attrs);
	    
	    /* paint object for drawing in onDraw */
	    circlePaint = new Paint();
	    
	   /* get the attributes specified in attrs.xml using the name we included */
	    TypedArray a = context.getTheme().obtainStyledAttributes(attrs, R.styleable.PieUI, 0, 0);
	    
	    try {
	        /* get the color specified using the names in attrs.xml */
	        circleColor = a.getInteger(R.styleable.PieUI_circleColor, 0);//0 is default
	        
	    } finally {
	        a.recycle();
	    }
	}
	
	/**
     * onDraw
     *  - draws the pie
     * @since 2014-11-13
     * @param canvas (Canvas)
     * @return void
     */
	@Override
	protected void onDraw(Canvas canvas) {
	    /* draw the View */
		/* get half of the width and height as we are working with a circle */
		int centerX = this.getMeasuredWidth()/2;
		int centerY = this.getMeasuredHeight()/2+65;
		
		/* get the radius as half of the width or height, whichever is smaller */
		/* subtract fifteen so that it has some space around it */
		int radius = 0;
		if(centerX>centerY)
		    radius=centerY-15;
		else
		    radius=centerX-15;
		oval.set(centerX-radius, centerY-radius, centerX+radius, centerY+radius);
		circlePaint.setAntiAlias(true);
		//circlePaint.setMaskFilter(new BlurMaskFilter(150, Blur.OUTER));
		for (Slice s : slices) {
				if(s.isHilighted()){
					circlePaint.setColor(s.getLightColor());
				}
				else{
					circlePaint.setColor(s.getColor());
				}
               canvas.drawArc(oval, s.getStartAngle(), s.getSweepAngle(), true, circlePaint);
               
               //postDelayed(this, 16);
            }
		}
	/**
     * draw
     *  - called by PieScheduleUI to draw the pie
     * @since 2014-11-13
     * @param ps (PieSchedule)
     * @return void
     */
	public void draw(ArrayList<Slice> arr){
		slices = arr;
		invalidate();
	}
	
	
}