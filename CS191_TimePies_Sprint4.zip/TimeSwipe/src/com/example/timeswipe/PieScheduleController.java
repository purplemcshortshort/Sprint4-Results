/**
 * REVISED BSD LICENSE
 * Copyright (c) 2015, Patricia Kelly D. Co, Kenneth T. Otsuka, Mary Jane T. Rubio
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright
      notice, this list of conditions and the following disclaimer in the
      documentation and/or other materials provided with the distribution.
    * Neither the name of the <organization> nor the
      names of its contributors may be used to endorse or promote products
      derived from this software without specific prior written permission.

 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL Patricia Kelly Co, Mary Jane T. Rubio, and 
 * Kenneth T. Otsuka BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT 
 * OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS 
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, 
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY 
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * @author Mary Jane T. Rubio
 * This is a course requirement for CS 192 Software Eng'g II under the supervision of 
 * Prof. Ma. Rowena C. Solamo of the Department of Computer Science, College of Engineering, 
 * University of the Philippines, Diliman for AY 2014-2015.
 */
/**
 * Code History
 * @version 1.0
 * @author Mary Jane T. Rubio
 * @since 2015-11-20
 * Initial code.
 * @version 1.1
 * @author Mary Jane T. Rubio
 * @since 2015-02-10
 * Changed initPieSchedule(), returns a PieSchedule instead of void
 * Added method save(PieSchedule);
 * @version 1.2
 * @author Mary Jane T. Rubio
 * @since 2015-02-16
 * Changed the times' data type from String to Time and long.
 * @version 1.3
 * @author Mary Jane T. Rubio
 * @since 2015-02-27
 * Added method addTask
 */
/**
 * Created on 2014-11-20
 * Developed by Purple McShortShort
 * Client Pink PlastiCS
 * The controller for the application's boundary, object and DAO classes.
 */
package com.example.timeswipe;

import java.util.ArrayList;
import java.util.Arrays;

import android.graphics.Color;

/**
 * Contains methods that connects the boundary, object, and DAO classes for the PieSchedule.
 *
 */
public class PieScheduleController {
	
	public static Task tempTask;
	public static int tempIndex1;
	public static int tempIndex;
	public static int tempColor;
     /**
      * initPieSchedule
      *  - Creates the saved PieSchedule
      * @since 2014-11-20
      * @param void
      * @return the PieSchedule to be initialized
      */
     public static PieSchedule initPieSchedule(){
          return PieScheduleDao.read();
     }
     
     /**
      * reset
      *  - Sets all the times to 00:00:00 and deletes all the slices. Calls PieScheduleDao.write(PieSchedule) to save its state.
      * @since 2014-11-20
      * @param ps The PieSchedule to be reset (PieSchedule)
      * @return void
      */
     public static void reset(PieSchedule ps){
          ps.setStartTime(new Time(-1,-1,-1));
          ps.setEndTime(new Time(-1,-1,-1));
          ps.setRemTime(new Time(-1,-1,-1));
          while(ps.getSize()>0)
               ps.deleteSlice(0);
          PieScheduleDao.write(ps);
     }
     
     /**
      * save
      *  - saves the PieSchedule to source file
      * @since 2015-02-16
      * @param ps The PieSchedule (PieSchedule)
      * @return void
      */
     public static void save(PieSchedule ps){
          PieScheduleDao.write(ps);
     }
     /**
      * addTask
      *  - adds and saves task from user input
      * @since 2015-02-27
      * @param ps (PieSchedule)
      * @param color (int)
      * @return void
      */
	public static void addTask(PieSchedule ps, int color) {
		int numSlices = ps.getSize()+1;
		float sweepAngle = 360/numSlices;
		
		int i = 0;
		for(;i<numSlices-1;i++){
			Slice s = ps.getSlice(i);
			s.setStartAngle(-90+i*sweepAngle);
			s.setSweepAngle(sweepAngle);
		}
		ps.addSlice(new Slice(-90 + i*sweepAngle,  360-sweepAngle*(numSlices-1), color, new Time(),tempTask));
		allocateTime(ps);
	}
	
	public static int getSliceWithColor(PieSchedule ps, int color){
		int i, size = ps.getSize();
		for(i = 0; i < size; i++){
			Slice s = ps.getSlice(i);
			if(s.getColor() == color || s.getLightColor() == color){
				return i;
			}
		}
		return -1;
	}
	
	public static void allocateTime(PieSchedule ps){
		/* EDIT THIS AFTER IMPLEMENTING RESIZE */
		long totalSec = ps.getRemTime().totalInSec();
		if(totalSec >=0){
			int size = ps.getSize();
			if(size > 0){
				long remainingSecToBeAssigned = totalSec;
				int i;
				for(i = 0; i < size-1; i++){
					Slice s = ps.getSlice(i);
					float sw = s.getSweepAngle();
					float scale = sw/360;
					long sliceSec = (long)(scale*totalSec);
					s.setRemTime(new Time(sliceSec));
					remainingSecToBeAssigned = remainingSecToBeAssigned - sliceSec; 
				}
				Slice s = ps.getSlice(i);
				s.setRemTime(new Time(remainingSecToBeAssigned));
			}
		}
		save(ps);
	}
	
	public static void deleteTask(PieSchedule ps){
		Slice d = ps.getSlice(tempIndex);
		ps.deleteSlice(tempIndex);
		
		int numSlices = ps.getSize();
		if(numSlices > 0){
			float a = d.getSweepAngle()/((float)(numSlices));
			
			float sw, sa = (float)-90, rem = (float)360;
			int i = 0;
			for(;i<numSlices-1;i++){
				Slice s = ps.getSlice(i);
				sw = s.getSweepAngle()+a;
				s.setStartAngle(sa);
				s.setSweepAngle(sw);
				sa = sa+sw;
				rem = rem - sw;
			}
			Slice s = ps.getSlice(i);
			s.setStartAngle(sa);
			s.setSweepAngle(rem);
		}
		allocateTime(ps);
	}
	
	public static void select(PieSchedule ps){
		Slice s = ps.getSlice(tempIndex);
		s.lightenColor();
	}
	
//	public static void switchSlices(PieSchedule ps){
//		Slice s1 = ps.getSlice(tempIndex);
//		Slice s2 = ps.getSlice(tempIndex1);
//		s2.setOriginalColor();
//		
//		ps.getSlices().set(tempIndex1, s1);
//		ps.getSlices().set(tempIndex, s2);
//		int numSlices = ps.getSize();
//		if(numSlices > 0){
//			float sw, sa = (float)-90;
//			int i = 0;
//			for(;i<numSlices;i++){
//				Slice s = ps.getSlice(i);
//				sw = s.getSweepAngle();
//				s.setStartAngle(sa);
//				sa = sa+sw;
//			}
//		}
//		save(ps);
//	}
	
	public static void moveSlice(PieSchedule ps){
		int numSlices = ps.getSize();
		
		if(numSlices > 0){
			int from = tempIndex1;
			int to = tempIndex;
			Slice slice = ps.getSlice(from);
			slice.setOriginalColor();
			
			float sa = slice.getStartAngle();
			if(from<to){ 
				for(; from<to; from++){
					Slice s = ps.getSlice(from+1);
					s.setStartAngle(sa);
					ps.getSlices().set(from, s);
					sa = sa +s.getSweepAngle();
				}
				slice.setStartAngle(sa);
				ps.getSlices().set(to, slice);
			}
			else if(from>to){
				sa = sa+slice.getSweepAngle();
				for(; from>to; from--){
					Slice s = ps.getSlice(from-1);
					sa = sa - s.getSweepAngle();
					s.setStartAngle(sa);
					ps.getSlices().set(from, s);
				}
				sa = sa - slice.getSweepAngle();
				slice.setStartAngle(sa);
				ps.getSlices().set(to, slice);
			}
		}
		save(ps);
	}
}